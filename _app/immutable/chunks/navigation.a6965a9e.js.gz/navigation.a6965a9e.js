import{j as o}from"./singletons.6ca0b673.js";const e=o("goto");export{e as g};
