import{w as a}from"./index.0c50763a.js";const t=a();export{t as a};
