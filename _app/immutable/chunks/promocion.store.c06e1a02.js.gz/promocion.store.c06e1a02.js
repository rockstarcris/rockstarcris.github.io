import{w as o}from"./index.0e16d72c.js";const t=o();export{t as p};
