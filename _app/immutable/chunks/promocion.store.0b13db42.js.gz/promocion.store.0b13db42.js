import{w as o}from"./index.3c8b91c5.js";const t=o();export{t as p};
