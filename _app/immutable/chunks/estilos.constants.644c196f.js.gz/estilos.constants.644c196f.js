const o={BOTÓN_DESACTIVADO:"pointer-events-none cursor-not-allowed opacity-50",CARGANDO:"bg-light-color animate-pulse",CARGANDO_SPAN:"bg-light-color animate-pulse w-52 inline-block"};export{o as E};
