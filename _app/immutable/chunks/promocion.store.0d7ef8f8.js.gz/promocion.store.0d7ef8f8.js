import{w as o}from"./index.d2456d52.js";const t=o();export{t as p};
