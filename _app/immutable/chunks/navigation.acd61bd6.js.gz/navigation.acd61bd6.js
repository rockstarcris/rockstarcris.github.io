import{j as o}from"./singletons.18020170.js";const e=o("goto");export{e as g};
