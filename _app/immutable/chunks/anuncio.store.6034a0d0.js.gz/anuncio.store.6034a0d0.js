import{w as a}from"./index.3c8b91c5.js";const t=a();export{t as a};
