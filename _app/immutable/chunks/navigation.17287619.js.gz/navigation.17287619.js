import{j as o}from"./singletons.fdcfb009.js";const e=o("goto");export{e as g};
