import{w as r}from"./index.4f3efb00.js";const a=r();export{a as r};
