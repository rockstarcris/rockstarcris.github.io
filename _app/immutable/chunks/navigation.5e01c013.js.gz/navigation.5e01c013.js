import{j as o}from"./singletons.44e8e7b0.js";const e=o("goto");export{e as g};
