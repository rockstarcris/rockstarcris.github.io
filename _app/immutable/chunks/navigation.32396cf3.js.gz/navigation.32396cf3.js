import{j as o}from"./singletons.64777d0a.js";const e=o("goto");export{e as g};
