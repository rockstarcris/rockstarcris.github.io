import{w as r}from"./index.3c8b91c5.js";const a=r();export{a as r};
