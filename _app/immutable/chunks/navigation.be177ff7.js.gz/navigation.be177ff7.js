import{j as o}from"./singletons.11912e9e.js";const e=o("goto");export{e as g};
