import{j as o}from"./singletons.417b4396.js";const e=o("goto");export{e as g};
