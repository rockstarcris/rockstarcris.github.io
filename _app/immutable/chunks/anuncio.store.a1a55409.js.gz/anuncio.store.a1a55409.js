import{w as a}from"./index.da14ca20.js";const t=a();export{t as a};
