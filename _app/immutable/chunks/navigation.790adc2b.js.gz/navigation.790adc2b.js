import{j as o}from"./singletons.4da16b26.js";const e=o("goto");export{e as g};
