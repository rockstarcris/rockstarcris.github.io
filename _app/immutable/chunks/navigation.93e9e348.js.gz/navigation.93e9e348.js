import{j as o}from"./singletons.91f34b20.js";const e=o("goto");export{e as g};
