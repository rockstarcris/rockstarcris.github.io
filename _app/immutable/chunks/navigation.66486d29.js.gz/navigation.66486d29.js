import{j as o}from"./singletons.8c144827.js";const e=o("goto");export{e as g};
