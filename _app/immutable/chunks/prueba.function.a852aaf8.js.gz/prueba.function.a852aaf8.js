import"./index.ac55fbe5.js";import{t as r}from"./state.9cc63495.js";import{I as a}from"./icon.component.2e0addc6.js";const n=async o=>{try{await o()}catch(t){r(t,{icon:a})}};export{n as p};
