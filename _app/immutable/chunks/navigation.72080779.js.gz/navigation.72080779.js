import{j as o}from"./singletons.72b93664.js";const e=o("goto");export{e as g};
