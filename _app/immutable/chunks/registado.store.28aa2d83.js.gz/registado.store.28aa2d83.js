import{w as r}from"./index.bd4f1f25.js";const a=r();export{a as r};
