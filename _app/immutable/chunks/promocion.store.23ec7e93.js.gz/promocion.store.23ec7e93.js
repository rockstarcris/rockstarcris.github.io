import{w as o}from"./index.da14ca20.js";const t=o();export{t as p};
