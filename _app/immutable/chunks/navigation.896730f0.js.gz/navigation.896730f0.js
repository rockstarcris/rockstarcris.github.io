import{j as o}from"./singletons.f706b260.js";const e=o("goto");export{e as g};
