import{w as o}from"./index.af7c2099.js";const t=o();export{t as p};
