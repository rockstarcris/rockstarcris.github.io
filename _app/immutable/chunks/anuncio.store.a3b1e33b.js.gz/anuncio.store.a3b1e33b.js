import{w as a}from"./index.0e16d72c.js";const t=a();export{t as a};
