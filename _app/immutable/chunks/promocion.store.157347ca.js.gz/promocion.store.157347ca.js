import{w as o}from"./index.bd4f1f25.js";const t=o();export{t as p};
