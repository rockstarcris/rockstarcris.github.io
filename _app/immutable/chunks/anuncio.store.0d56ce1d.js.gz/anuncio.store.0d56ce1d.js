import{w as a}from"./index.af7c2099.js";const t=a();export{t as a};
