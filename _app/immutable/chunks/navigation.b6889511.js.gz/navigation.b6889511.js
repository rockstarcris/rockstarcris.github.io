import{j as o}from"./singletons.a16e7a99.js";const e=o("goto");export{e as g};
