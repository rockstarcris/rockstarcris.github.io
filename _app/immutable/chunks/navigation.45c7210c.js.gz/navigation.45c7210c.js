import{j as o}from"./singletons.1f6ea690.js";const e=o("goto");export{e as g};
