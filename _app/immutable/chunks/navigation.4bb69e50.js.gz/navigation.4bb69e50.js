import{j as o}from"./singletons.1f699650.js";const e=o("goto");export{e as g};
