import{w as r}from"./index.3c8b91c5.js";const a=r(),e=r({perfil:!0});export{e as c,a as p};
