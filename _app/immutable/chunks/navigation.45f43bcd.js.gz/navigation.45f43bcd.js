import{j as o}from"./singletons.8730267b.js";const e=o("goto");export{e as g};
