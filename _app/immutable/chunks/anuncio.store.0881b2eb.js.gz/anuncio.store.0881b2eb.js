import{w as a}from"./index.bd4f1f25.js";const t=a();export{t as a};
