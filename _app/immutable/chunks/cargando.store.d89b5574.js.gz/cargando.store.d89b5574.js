import{w as r}from"./index.0e16d72c.js";const a=r(),e=r({perfil:!0});export{e as c,a as p};
