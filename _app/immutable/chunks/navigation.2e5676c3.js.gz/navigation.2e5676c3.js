import{j as o}from"./singletons.1c6fa508.js";const e=o("goto");export{e as g};
