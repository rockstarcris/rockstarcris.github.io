import{w as r}from"./index.af7c2099.js";const a=r();export{a as r};
