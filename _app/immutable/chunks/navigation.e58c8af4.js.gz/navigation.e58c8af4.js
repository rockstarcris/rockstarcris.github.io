import{h as o}from"./singletons.05430a1e.js";const e=o("goto");export{e as g};
