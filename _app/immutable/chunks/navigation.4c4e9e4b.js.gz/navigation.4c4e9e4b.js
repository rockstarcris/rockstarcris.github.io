import{j as o}from"./singletons.73271345.js";const e=o("goto");export{e as g};
