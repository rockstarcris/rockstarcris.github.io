import{j as o}from"./singletons.411d52a7.js";const e=o("goto");export{e as g};
