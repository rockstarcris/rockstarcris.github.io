import{j as o}from"./singletons.c5bd73e4.js";const e=o("goto");export{e as g};
