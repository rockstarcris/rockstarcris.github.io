import{w as o}from"./index.4f3efb00.js";const t=o();export{t as p};
