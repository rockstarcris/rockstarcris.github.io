import{j as o}from"./singletons.1c116ea7.js";const e=o("goto");export{e as g};
