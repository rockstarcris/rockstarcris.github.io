import{w as t}from"./index.3c8b91c5.js";const o=t();export{o as t};
