import{w as r}from"./index.da14ca20.js";const a=r();export{a as r};
