import{j as o}from"./singletons.b1257801.js";const e=o("goto");export{e as g};
