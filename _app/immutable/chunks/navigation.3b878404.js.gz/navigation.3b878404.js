import{j as o}from"./singletons.a0d9104f.js";const e=o("goto");export{e as g};
