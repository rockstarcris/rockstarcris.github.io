import{w as r}from"./index.0c50763a.js";const a=r();export{a as r};
