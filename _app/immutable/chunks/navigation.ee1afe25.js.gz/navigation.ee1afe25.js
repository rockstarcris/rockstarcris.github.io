import{j as o}from"./singletons.8dc4417f.js";const e=o("goto");export{e as g};
