import{j as o}from"./singletons.c12f53d9.js";const e=o("goto");export{e as g};
