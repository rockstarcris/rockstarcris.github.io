import{w as a}from"./index.4f3efb00.js";const t=a();export{t as a};
