import{w as o}from"./index.0c50763a.js";const t=o();export{t as p};
