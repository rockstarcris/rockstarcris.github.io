import{h as o}from"./singletons.0b1240dd.js";const e=o("goto");export{e as g};
