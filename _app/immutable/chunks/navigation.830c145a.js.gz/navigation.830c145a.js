import{j as o}from"./singletons.f1ef421e.js";const e=o("goto");export{e as g};
