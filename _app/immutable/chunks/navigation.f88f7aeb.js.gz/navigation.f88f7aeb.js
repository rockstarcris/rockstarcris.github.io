import{j as o}from"./singletons.ce15816d.js";const e=o("goto");export{e as g};
